# Newton Raphson Method
## Aim
To implement the Newton Raphson method to numerically improve the accuracy of the roots of non-trivial equations using MATLAB.
## Algorithm
- Step 1: Read the approximate root value to the given function to work with, say $x$
- Step 2: Read the tolerance limit, say e
- Step 3: Compute a better approximation using Newton Raphson formula
    $$x_{n+1} = x_n - \frac{f(x_n)}{f^{\prime}(x_n)}$$
- Step 4:$f^{\prime}(x_n)$ could be computed by directly providing the derivative manually to MATLAB or by a simple approximation
    $$f^{\prime}(x_n) = \frac{f(x_n + 0.001) - f(x_n - 0.001)}{0.002}$$
- Step 5: Calculate the percentage error value using
    $$\Bigl | \frac{x_{i} - x_{i-1}}{x_i}\Bigr | \times 100$$
- Step 6: If $\left|(x_{n+1} - x_{n}) / x_{n} \right|$ is greater than or equal to e proceed to step 7 else goto step 3
- Step 7: Plot percentage error vs no of iterations bar graph
- Step 8: Display the root value computed earlier
## Code
```
function outputnum = func(x)
outputnum = x.^2 - 5;
end

function root = newtonRaphson(x, e)

tmp = 0.0;
er = zeros(100);
count = 1;

while (abs((x - tmp) / x ) >= e)
    tmp = x;
    x = x - 2 * 0.001 * func(x) / (func(x + 0.001) - func(x - 0.001));
    er(count) = abs( (x - tmp) / x ) * 100;
    count = count + 1;
end

n = count;
r = 1:n;
bar(r(1:n-1),er(2:n));
xlabel('No of Iterations');
ylabel('Percentage Error');
title('Newton-Raphson Method - % Error vs Iterations');

root = vpa(x);
end
```
## Output
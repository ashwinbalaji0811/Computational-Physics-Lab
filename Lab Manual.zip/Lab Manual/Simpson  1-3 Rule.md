# Simpson's 1/3 Rule

## Aim
To implement Simpson's 1/3 Rule in MATLAB and compute integrals numerically.

## Algorithm
- Step 1: Generate a vector $x$ such that it contains domain values in desired integration range, say $[x_0, x_n]$ for given function $f(x)$
-  Step 2: Generate a vector $y$ for any desired function $f(x)$ such that $y = f(x)$
- Step 3: Determine step size $h$ and number of points $n$ using $x$
- Step 4:Compute the integral $$\int^{x_n}_{x_0} ydx$$ using the **Simpson's 1/3 Rule** formula
$$\int^{x_n}_{x_0} ydx = \frac{h}{3} [y_0 + 4(y_1 + y_3 + \dots + y_{n-1}) + 2(y_2 + y_4 + \dots + y_{n-2}) + y_n]$$
- Step 5: Display the numerical value of the given definite integral

## Code
```
function numInt = simpson13(x, y)

h = x(2) - x(1);
[m, n] = size(y);
sum = 0.000;

for count = 1:n
    if ( count >= 2 ) & ( count <= n-1 ) & ( mod(count, 2) ==  0)
        sum = sum + 4 * y(count);
    end
    if ( count >= 3 ) & ( count <= n-2 ) & ( mod(count, 2) ==  1)
        sum = sum + 2 * y(count);
    end
end

sum = sum + y(1) + y(n);
sum = h * sum / 3.0;

numInt = vpa(sum);
end
```

## Output
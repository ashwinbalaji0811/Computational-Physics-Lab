# Romberg integration

## Aim
To implement romberg integration recursively in MATLAB to compute definite integrals numerically with varying accuracy.

## Algorithm
To compute
    $$\int^{b}_{a} f(x) dx$$
    using **Romberg's Integration** Method, define a **recursive function** using the below definitions
    $$h_n = \frac{b - a}{2^n}$$
    $$R(0,0) = \frac{f_b - f_a}{h_1}$$
    $$R(n, 0) = \frac{R(n-1, 0)}{2} + h_n \sum^{2^{n-1}}_{k = 1} f\left (a + \frac{2k-1}{h_n}\right)$$
    $$R(n,m) = R(n,m-1) + \frac{R(n,m-1) - R(n-1,m-1)}{4^m -1}$$
    where $n \geq m \text{ and } m \geq 1$. Here,

- The zeroth extrapolation, R(n, 0), is equivalent to the trapezoidal rule with $2^n + 1$ points
- The first extrapolation, R(n, 1), is equivalent to Simpson's rule with $2^n + 1$ points
- The second extrapolation, R(n, 2), is equivalent to Boole's rule with $2^n + 1$ points

## Code
```
function [ Result ] = romberg( fun, x1, x2, n, m )

func = inline(fun);
sum = 0.0;
h = @(t) ((x2 - x1) / (2^t));

if( (n == 0) & (m == 0) )
    Result = h(1) * (func(x1) + func(x2));
elseif ( m == 0)
    for k = 1:(2^(n-1))
        sum = sum + func(x1 + (2*k - 1)*h(n));
    end
    Result = ( 0.5 * romberg(fun, x1, x2, n-1, 0) + sum*h(n));
else
    Result = ((4^m)*romberg(fun, x1, x2, n, m-1) - romberg(fun, x1, x2, n-1, m-1)) / (4^m - 1);
end

end
```

# Secant Method
## Aim
To implement the Secant method to numerically improve the accuracy of the roots of non-trivial equations using MATLAB.
## Algorithm
- Step 1: Read the approximate root value to the given function to work with, say $x$
- Step 2: Read the tolerance limit, say e
- Step 3: Compute a better approximation using Secant method formula
    $$x_{n+1} = x_n - \frac{f(x_n)}{f^{\prime}(x_n)}$$
- Step 4: Calculate the percentage error value using
    $$\Bigl | \frac{x_{i} - x_{i-1}}{x_i}\Bigr | \times 100$$
- Step 5: If $\left|(x_{n+1} - x_{n}) / x_{n} \right|$ is greater than or equal to e proceed to step 6 else goto step 3
- Step 6: Plot percentage error vs no of iterations bar graph
- Step 7: Display the root value computed earlier
- Step 8: Compare percentage error vs no of iterations graph with Newton-Raphson's results
## Code
```
function outputnum = func(x)
outputnum = x.^2 - 5;
end

function root = secant(x1, x2, e)

x = 0.0;
er = zeros(100);
count = 1;

while (abs((x1 - x2) / x2 ) >= e)
    x = x2;
    x2 = ( x1 * func(x2) - x2 * func(x1) ) / ( func(x2) - func(x1) );
    x1 = x;
    er(count) = abs( (x1 - x2) / x2 ) * 100;
    count = count + 1;
end

n = count;
r = 1:n;
bar(r(1:n-1),er(2:n));
xlabel('No of Iterations');
ylabel('Percentage Error');
title('Secant Method - % Error vs Iterations');

root = vpa(x2);

end
```
## Output
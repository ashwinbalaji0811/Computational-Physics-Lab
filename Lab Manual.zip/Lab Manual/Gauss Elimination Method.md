# Gauss Elimination Method

## Aim
To implement Gauss Elimination method to solve a system of linear equations exactly in MATLAB.
## Algorithm
- Step 1: Check for proper dimensions of Matrix A and Vector b 
- Step 2: Compute the formula for iterations of $k = 1 \dots n-1, i = k+1 \dots n \text{ and } j = k+1 \dots n$
    $$a_{ij} = a_{ij} – \frac{a_{ik} \times a_{kj}}{a_{kk}}$$
- Step 3: Check $a_{ii}$ is not equal to zero. If zero, swap rows $i \text{ and } i-1$. This is called partial pivoting.
- Step 4: Now for the back substitution, use 
    $$x_n = b_{n}/a_{nn}$$
- Step 5: Compute remaining solutions by iterating $k = n-1 \dots 1$ the below relation
    $$x_k = \frac{a_{kn+1} – \sum^{n}_{j = k + 1} a_{kj} \times x_j}{a_{kk}}$$
-  Step 6: Return/Print the vector x to display the solutions for given system of linear equations represented by A and b.

## Code
```
function [ x ] = gaussElimination( A, b)

sz = size(A);
if sz(1) ~= sz(2)
    fprintf('A is not n by n\n');
    clear x;
    return;
end
 
n = sz(1);

if n ~= sz(1)
    fprintf('b is not 1 by n.\n');
    return
end
 
x = zeros(n,1);
aug = [A b];
tempmatrix = aug;
 
for i= 2:sz(1)
    tempmatrix(1,:) = tempmatrix(1,:) / max(tempmatrix(1,:));
    temp = find(abs(tempmatrix) - max(abs(tempmatrix(:,1))));
    if length(temp) > 2
        for j = 1:length(temp)-1
            if j ~= temp(j)
                maxi = j;
                break;
            end
        end
    else
        maxi = 1;
    end
    if maxi ~= 1
        temp = tempmatrix(maxi,:);
        tempmatrix(maxi,:) = tempmatrix(1,:);
        tempmatrix(1,:) = temp;
    end
    for j = 2:length(tempmatrix)-1
        tempmatrix(j,:) = tempmatrix(j,:) - tempmatrix(j,1) ...
            / tempmatrix(1,1) * tempmatrix(1,:);
        if tempmatrix(j,j) == 0 || ...
                isnan(tempmatrix(j,j)) || abs(tempmatrix(j,j)) == Inf
            fprintf('Error: Matrix is singular.\n');
            clear x;
            return
        end
    end
    aug(i-1:end,i-1:end) = tempmatrix;
    tempmatrix = tempmatrix(2:end,2:end);
end

x(end) = aug(end,end) / aug(end,end-1);

for i = n-1:-1:1
    x(i) = (aug(i,end) - dot(aug(i,1:end-1),x)) / aug(i,i);
end
 
end
```
## Output
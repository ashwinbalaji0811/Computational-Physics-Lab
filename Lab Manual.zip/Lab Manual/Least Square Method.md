# Least Square Method
## Aim
To implement Least Square Method in MATLAB to find the least error fit for the given data $(x_1, y_1) \to (x_n, y_n)$.
## Algorithm
- Step 1: Compute $\sum_{i = 1}^n x_i$, $\sum_{i = 1}^n x^2_i$, $\sum_{i = 1}^n x_i y_i$ and $\sum_{i = 1}^n y_i$
- Step 2: Define a matrix $\mathcal{A}$

$$\mathcal{A} = \begin{pmatrix}
n & \sum_{i = 1}^n x_i\\
\sum_{i = 1}^n x_i & \sum_{i = 1}^n x^2_i 
\end{pmatrix}$$
and a vector $\mathcal{v}$
$$\mathcal{v} = \begin{pmatrix}
\sum_{i = 1}^n y_i \\
\sum_{i = 1}^n x_i y_i
\end{pmatrix}$$

- Use Gauss Elimination to solve $\mathcal{A} \Phi =\mathcal{v}$
- The components of $\Phi$ gives us the slope and intercept of the best fit line.
## Code
```
% input in the form of matrix, each row is a (x, y).
input = [...
  1, 2;...
  2, 4.5;...
  3, 5.9;...
  4, 8.1;...
  5, 9.8;...
  6, 12.3];

m = size(input, 1);
n = size(input, 2);
x = input(:,1:n-1);
y = input(:,n);

% The first column of matrix X is populated with ones,
% and the rest columns are the x columns of the input.
X = ones(m, n);
X(:,2:n) = input(:,1:n-1);

% Try to find the a that minimizes the least square error Xa - y.
% Project y onto the C(X) will give us b which is Xa.

% The relationship is X'Xa = X'b

% Use left division \ to solve the equation, which is equivalent
% to a = inverse(X'*X)*X'*y, but computationally cheaper.
a = (X' * X) \ (X' * y)
b = X*a
least_square_error = sum((b - y) .^ 2)

% Plot the best fit line.
plot(x, b);
title(sprintf('y = %f + %fx', a(1), a(2)));
xlabel('x');
ylabel('y');

hold on;
% Plot the input data.
plot(x, y, '+r');
hold off;
pause;
```
## Output
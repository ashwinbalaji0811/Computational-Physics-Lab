# Gauss Jordan Method
## Aim
To implement Gauss Jordan method to solve a system of linear equations exactly in MATLAB.
## Algorithm
- Start from $k=0$ and $l=0$.
- Increment $k$ by one unit.
- Increment $l$ by one unit.
- Stop the algorithm if $l>L$. Else proceed to the next step.
- If $A_{il}=0$ for $i=k, \cdots ,K$, return to step 3. Else proceed to the next step.
- Interchange the k-th equation with any equation $i$ (with $i>k$) such that $A_{il} \neq 0$ (if $i=k$ there is no need to perform an interchange).
- Divide the k-th equation by $A_{kl}$.
- For $i=1,\cdots ,k-1$ and $i=k+1,\cdots ,K$, subtract the k-th equation multiplied by $A_{il}$ from the i-th equation.
- If $k<K$, return to step 2. Else stop the algorithm.
## Code
```
function solution = gauss_jordan(A, b, n)
     M = [A, b];
    for i = 2:n
        for j = 1:i-1
            M(i,:) = M(i,:) - M(j,:)*(M(i,j)/M(j,j));
        end
    end
   
   for i = n-1:-1:1
        for j = n:-1:i+1
            M(i,:) = M(i,:) - M(j,:)*(M(i,j)/M(j,j));
        end
   end
   
   A = M(1:n,1:n);
   b = M(:,n+1);
   
   disp(A)
    for i = 1:n
        solution(i,1) = b(i)/A(i,i);
    end
end
```
## Output
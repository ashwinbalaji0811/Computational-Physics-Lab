# Euler Method
## Aim
To implement Euler Method in MATLAB to solve the differential equation $f^{\prime}(x) = f(x, y)$ for it's particular solution numerically.

## Algorithm
- Define function $f(x)$
- Get the values of $x_0, y_0, h \text{ and } x_n$. Here $x_0$ and $y_0$ are the initial conditions, $h$ is the interval, $x_n$ is the required value
- Define $n = \frac{(x_n – x_0)}{h} + 1$
- Start loop from $i=1$ to $n$
- $y = y_0 + h \times f(x_0,y_0)$
- $x = x + h$
- Print values of $y_0$ and $x_0$
- Check if $x \leq x_n$
- If yes, assign $x_0 = x$ and $y_0 = y$ and continue loop
- If no, End loop $i$

## Code
```
function euler(fun, x0, y0, h, fname)

func = inline(fun);

x = zeros(1001);
y = x;

x(1) = x0;
y(1) = y0;

fid = fopen(fname,'w');

i = 0;
n = 1/h;

for i = 2:n
    x(i) = x(i-1) + h;
    y(i) = y(i-1) + h * func(x(i-1),  y(i-1));
    
    fprintf(fid,'%8.4f %8.4f \n', x(i), y(i));
end

plot(x,y);

end
```
## Output

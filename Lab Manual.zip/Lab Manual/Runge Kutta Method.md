# Runge Kutta Method
## Aim
To implement 2nd and 4th order Runge Kutta Methods to solve a Differential Equation for it's particular solution numerically using MATLAB for the derivative function $f(x, y)$ in the domain $[a, b]$

## Algorithm
- Step 1: Define the function $f(x, y)$
- Step 2: Determine step size $h$ for desired accuracy
- Step 3: Compute $y_1$ from $(x_0, y_0)$ and $x_1 = x_0 + h$ using the following formulas

For 2nd Order:
$$y_{i+1} = y_i + \frac{k_1 + k_2}{2}h$$

where

$$k_1 = f(x_i, y_i) \text{ and } k_2 = f(x_i + h, k_1 h)$$
and for 4th Order:

$$y_{i+1} = y_i + \frac{k_1 + 2k_2 + 2k_3 + k_4}{6}$$

where
$$k1 = h f(x_i, y_i), \text{ } k_2 = h f(x_i + \frac{h}{2}, y_i + \frac{k_1}{2})$$

$$
k_3 = h f(x_i + \frac{h}{2}, y_i + \frac{k_2}{2}),\text{ }
k_4 = h f(x_i + \frac{h}{2}, y_i + \frac{k_3}{2})$$

- Step 5: Check if $x_n$ is equal to $b$, if yes then, plot the result else continue.
- Step 6: Save the vector $x$ and $y$ to a file for further reference.
## Code
### 2nd Order Implementation
```
function rkutta2(x0, y0, h, fname)

func = @(x,y) 4 * x ^ 3 + 0 * y;

fid = fopen(fname,'w');

i = 0;
n = 1/h;

x = zeros(n);
y = x;

x(1) = x0;
y(1) = y0;


k2 = @(x,y) func((x + h), (y + (func(x, y) * h)));

for i = 2:n
    x(i) = x(i-1) + h;
    y(i) = y(i-1) + 0.5 * (func(x(i-1), y(i-1)) ...
        + k2(x(i-1), y(i-1))) * h;

    fprintf(fid,'%8.4f %8.4f \n', x(i), y(i));
end

plot(x,y);

end
```
### 4th Order Implementation
```
function rkutta4(x0, y0, h, fname)

func = @(a, b) 4 * a ^ 3 + 0 * b;

x = zeros(10001);
y = x;

x(1) = x0;
y(1) = y0;

fid = fopen(fname,'w');

i = 0;
n = 1/h;

k1 = @(a,b) func(a, b);
k2 = @(a,b) func((a + h / 2.0), (b + (k1(a,b) / 2.0)));
k3 = @(a,b) func((a + h / 2.0), (b + (k2(a,b) / 2.0)));
k4 = @(a,b) func((a + h), (b + k3(a,b)));

for i = 2:n
    x(i) = x(i-1) + h;
    y(i) = y(i-1) + h * (k1(x(i-1),y(i-1)) + ...
        2 * k2(x(i-1),y(i-1)) + ...
        2 * k3(x(i-1),y(i-1)) + k4(x(i-1),y(i-1))) / 6.0;
    
    fprintf(fid,'%8.4f %8.4f \n', x(i), y(i));
end

plot(x,y);

end
```
## Output
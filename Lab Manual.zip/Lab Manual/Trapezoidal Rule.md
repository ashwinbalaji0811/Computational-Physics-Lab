# Trapezoidal Rule
## Aim
To implement Trapezoidal Rule in MATLAB and compute integrals numerically.

## Algorithm
- Step 1: Generate a vector x such that it contains domain values in desired integration range, say $[x_0, x_n]$ for given function $f(x)$
- Step 2: Generate a vector y for any desired function $f(x)$ such that $y = f(x)$
- Step 3: Determine step size $h$ and number of points n using x
- Step 4:Compute the integral $$\int^{x_n}_{x_0} ydx$$ using the \textbf{Trapezoidal Rule} formula
$$\int^{x_n}_{x_0} ydx = \frac{h}{2} [y_0 + 2(y_1 + y_2 + \dots + y_{n-1}) + y_n]$$
- Step 5: Display the numerical value of the given definite integral
- Step 6: Compare the numerical accuracy of Simpson's 1/3 Rule with Trapezoidal Rule for different functions

## Code
```
function numInt = trapezoidal(x, y)

h = x(2) - x(1);
[m, n] = size(y);
sum = 0.000;

for count = 1:n
    sum = sum + y(count);
end

sum = 2.0 * sum - (y(1) + y(n));
sum = h * sum / 2.0;

numInt = vpa(sum);
end
```
## Output
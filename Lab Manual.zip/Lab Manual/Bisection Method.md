# Bisection Method
## Aim
To implement the Bisection method to numerically compute the roots of non-trivial equations using MATLAB.
## Algorithm
- Step 1: Read the range to work with, say $x_1$ and $x_2$
- Step 2: Read the tolerance limit, say e
- Step 3: Compute the no of iterations using the formula 
    $$\frac{\text{log}(|x_2 - x_1| / e ) }{\text{log}(2)}$$
- Step 4: If $f(x_1) \times f(x_2)$ is greater than 0 prompt the user about the invalid range and terminate the program
- Step 5: If $f(x_1) \times f(x_2)$ is less than 0 compute $$x = \frac{(x_1 + x_2) }{2}$$
- Step 6: If $\left|((x_1 - x_2) / x )\right|$ is greater than or equal to e proceed to step 7 else goto step 10
- Step 7: Calculate the percentage error value using  $$\Bigl | \frac{x_{i} - x_{i-1}}{x_i}\Bigr | \times 100$$
- Step 8: If $f(x_1) \times f(x)$ is less than 0 update $x_2$ as x and goto step 5 else goto step 9
- Step 9: Update $x_1$ as x and goto step 5
- Step 10: Plot percentage error vs no of iterations graph
- Step 11: Display the root of the equation in given interval, no of iterations computed earlier and actual no of iterations

## Code
```
function outputnum = func(x)
outputnum = x.^2 - 4;
end

function root = bisection()

er = zeros(100);
co = 0;

x1 = input('Enter value of x1: ');
x2 = input('Enter value of x2: ');
e = input('Enter value tolerance limit: ');

nTh = log( abs(x2 - x1) / e ) / log(2);

if func(x1) * func(x2) > 0 
    disp('Wrong Choice of Range, please check')
    return;
else    
    x = (x1 + x2) / 2;    
    while ( abs((x1 - x2) / x ) >= e) 
        co = co + 1;
        er(co) = x;
        x = (x1 + x2) / 2;
        er(co) = 100 * abs(( x - er(co) ) / x);
        if ((func(x) * func(x1)) < 0)           
            x2 = x;       
        else            
            x1 = x;        
        end        
    end    
end

r = 1:co;
plot(r(2:co),er(2:co));
xlabel('No of Iterations');
ylabel('Percentage Error');
title('Bisection Method - % Error vs Iterations');

fprintf('\nTheoretical value of No of Iterations: %i', floor(nTh));
fprintf('\nTotal no. of Iterations:  %i', co);
fprintf('\nRoot of the given function: %f', x);

root = x;
end
```
## Output
![[bis1.png]]
![[bis2.png]]